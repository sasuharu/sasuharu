import os, glob, hashlib

a = input()
print('Start')

path = os.getcwd()

body_dict={}
for curDir, dirs, files in os.walk(path):
    for file in files:
        name = curDir + '/' + file
        name = name.replace('\\', '/')
        
        try:
            f = open(name, 'rb')
        except PermissionError:
            pass
        else:
            v = hashlib.sha256(f.read()).hexdigest() # ハッシュ値の取得
            f.close()
            if v in list(body_dict.keys()):
                print('-----重複 Duplicate -----')
                print(body_dict[v])
                print(name)
            else:
                body_dict[v] = name

print('End')
a = input()